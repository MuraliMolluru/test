package de.telekom.onap.oran.closedloop.steps;

import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertEquals;

import de.telekom.onap.oran.rule.entity.RuleManagement;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;



public class RulesSteps { 
   
   private RuleManagement ruleMgmt = null;
   
   @Given("^Holmes UI is available$") 
   public void holmesUI() { 
      
       ruleMgmt = new RuleManagement();
       ruleMgmt.isUrlValid();
       System.out.println("User On Holmes UI");
       
   }
   
   @When("^SCTP_LINK_DOWN Rule created$") 
   public void addRuleIntoEngine() { 
      
       boolean flag = ruleMgmt.addRule(); 
       assertEquals(true, flag, "Add rule into holmes failed.");
   }
   
   @Then("^Validate if rule created successfully$") 
   public void validateRule() { 
      
       String ruleId = ruleMgmt.getRuleId();
       if(ruleId.equals("")) {
           assertEquals(true, true, "Rule not available in engine.");
       }
       else {
           assertTrue(true);
       }
   }
   
   @Then("^Update SCTP_LINK_DOWN rule created$") 
   public void updateRuleIntoEngine() { 
      
       boolean flag = ruleMgmt.updateRule(); 
       assertEquals(true, flag, "Update rule into holmes engine failed.");
   }
   
   @Then("^Delete SCTP_LINK_DOWN rule$") 
   public void deleteRuleFromEngine() { 
      
       boolean flag = ruleMgmt.deleteRule(); 
       assertEquals(true, flag, "delete rule from holmes engine failed.");
       
   }
       
} 