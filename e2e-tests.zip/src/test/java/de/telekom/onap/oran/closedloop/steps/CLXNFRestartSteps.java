
package de.telekom.onap.oran.closedloop.steps;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.junit.jupiter.api.BeforeAll;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import de.telekom.onap.dcae.vescollector.model.VesEvent;
import de.telekom.onap.oran.kafka.application.PolicyNotificationData;
import de.telekom.onap.oran.kafka.application.RestAssuredClient;
import de.telekom.onap.oran.kafka.configuration.Configuration;
import de.telekom.onap.oran.kafka.producer.WriteFaultMessageToKafka;
import de.telekom.onap.oran.kafka.util.DmaapMessageValidation;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.response.Response;

public class CLXNFRestartSteps {
	private static final Logger log = LoggerFactory.getLogger(CLXNFRestartSteps.class);
	private WriteFaultMessageToKafka faultMessageToKafka = null;
	private RestAssuredClient assuredClient = null;
	private DmaapMessageValidation dmaapMessageValidation = null;

	@BeforeAll
	public void setUp() {
		faultMessageToKafka = new WriteFaultMessageToKafka();
		assuredClient = new RestAssuredClient();
		dmaapMessageValidation = new DmaapMessageValidation(assuredClient);
	}

	@When("^Holmes Engine is available^")
	public void holmesEngineHealthCheck() {
		String url = Configuration.getConfiguration().getMsbUrl() + "/api/holmes-engine-mgmt/v1/healthcheck";
		Response response = assuredClient.get(url);
		assertEquals(200, response.getStatusCode());
	}
	
	@And("^Send DU1 Fault SCTP_LINK_DOWN alarm^")
	public void sendDU1SCTP_LINK_DOWNalarm() {
		String topicName = Configuration.getConfiguration().getKafkaFaultTopic();
		faultMessageToKafka.sendFmDownMessage_1();
		VesEvent vesDownEvent = faultMessageToKafka.getVesEvent();
		String expectedEventId = vesDownEvent.getEvent().getCommonEventHeader().getEventId();
		String actualEventId = dmaapMessageValidation.validateMessage(topicName, expectedEventId);
		assertEquals(expectedEventId, actualEventId);
	}
	
	@And("^Send DU2 Fault SCTP_LINK_DOWN alarm^")
	public void sendDU2SCTP_LINK_DOWNalarm() {
		String topicName = Configuration.getConfiguration().getKafkaFaultTopic();
		faultMessageToKafka.sendFmDownMessage_2();
		VesEvent vesDownEvent = faultMessageToKafka.getVesEvent();
		String expectedEventId = vesDownEvent.getEvent().getCommonEventHeader().getEventId();
		String actualEventId = dmaapMessageValidation.validateMessage(topicName, expectedEventId);
		assertEquals(expectedEventId, actualEventId);
	}

	@Then("^Onset policy message generated^")
	public void fmOnsetPolicyTrigger() {
		log.info("ONSET Policy triggering...");
		assertTrue(dmaapMessageValidation.isValidateFmPolicy("DCAE.HolmesInstance", "ONSET"));
		log.info("ONSET policy triggered...");
	}

	@And("^Policy receives Success notification from CDS^")
	public void fmPolicyCdsNotification() {
		log.info("Notification from CDS to Policy ...");
		String closedLoopControlName = dmaapMessageValidation.getClosedLoopControlName();
		PolicyNotificationData policyNotificationData = dmaapMessageValidation.getPolicyNotificationData();
		assertNotNull(policyNotificationData);
		assertEquals(closedLoopControlName, policyNotificationData.getClosedLoopControlName());
		assertEquals("CDS", policyNotificationData.getActor());
		assertEquals("RestartXNF", policyNotificationData.getOperation());
		assertEquals("Success", policyNotificationData.getOutCome());

	}

	@When("^Send DU1 SCTP_LINK_UP alarm^")
	public void sendDU1SCTP_LINK_UPAlarm() {
		String topicName = Configuration.getConfiguration().getKafkaFaultTopic();
		faultMessageToKafka.sendFmUpMessage_1();
		VesEvent vesDownEvent = faultMessageToKafka.getVesEvent();
		String expectedEventId = vesDownEvent.getEvent().getCommonEventHeader().getEventId();
		String actualEventId = dmaapMessageValidation.validateMessage(topicName, expectedEventId);
		assertEquals(expectedEventId, actualEventId);
	}

	@Then("^Abate policy message generated^")
	public void fmAbatePolicyTrigger() {
		log.info("First abated policy triggering...");
		assertTrue(dmaapMessageValidation.isValidateFmPolicy("DCAE.HolmesInstance", "ABATED"));
	}

	@When("^Send DU2 SCTP_LINK_UP alarm^")
	public void sendDU2SCTP_LINK_UPAlarm() {
		String topicName = Configuration.getConfiguration().getKafkaFaultTopic();
		faultMessageToKafka.sendFmUpMessage_2();
		VesEvent vesDownEvent = faultMessageToKafka.getVesEvent();
		String expectedEventId = vesDownEvent.getEvent().getCommonEventHeader().getEventId();
		String actualEventId = dmaapMessageValidation.validateMessage(topicName, expectedEventId);
		assertEquals(expectedEventId, actualEventId);
	}

}
