
package de.telekom.onap.oran.closedloop.steps;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import de.telekom.onap.oran.kafka.application.RestAssuredClient;
import de.telekom.onap.oran.kafka.configuration.Configuration;
import de.telekom.onap.oran.kafka.util.PolicyValidation;
import io.cucumber.java.en.And;
import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;
import io.restassured.response.Response;

public class CLPolicyMessageSteps {

    private static final Logger log = LoggerFactory.getLogger(CLPolicyMessageSteps.class);
    private RestAssuredClient assuredClient = null;
    private PolicyValidation policyValidation = null;
    private String policyName;
    private String policyVersion;
    
    @Given("^CL Policy$")
    public void doSomethingBefore() {
        assuredClient = new RestAssuredClient();
        policyValidation = new PolicyValidation(assuredClient);
        policyName = Configuration.getConfiguration().getPolicyName();
        policyVersion = Configuration.getConfiguration().getPolicyVersion();
    }
    
    /**
     * Create policy only if policy is not available already.
     * 
     **/
    @Given("^CL XNF Restart Operational Policy$") 
    public void createXNFRestartPolicy() {

        log.info("Creating Policy...");
        Response policyGetResponse = policyValidation.getPolicy();
        assertNotNull(policyGetResponse, "Get policy failed...");
        assertEquals(200, policyGetResponse.getStatusCode(), "Get policy failed...");
        assertFalse(policyValidation.isPolicyAvailable(policyGetResponse, policyName, policyVersion),
                "Policy already available...");

        Response policyCreateResponse = policyValidation.createPolicy(policyName, policyVersion);
        assertNotNull(policyCreateResponse);
        assertEquals(200, policyCreateResponse.getStatusCode(), "Policy creation failed...");

        log.info("Get policy details....");
        policyGetResponse = policyValidation.getPolicy();
        assertNotNull(policyGetResponse);
        assertEquals(200, policyGetResponse.getStatusCode(), "Get policy failed...");
        assertTrue(policyValidation.isPolicyAvailable(policyGetResponse, policyName, policyVersion));
        log.info("Policy created successfully...");
    }
    
    @Then("^Validate Policy creation$")
    public void validatePolicy() {
        log.info("Get policy details....");
        Response policyGetResponse = policyValidation.getPolicy();
        assertNotNull(policyGetResponse);
        assertEquals(200, policyGetResponse.getStatusCode(), "Get policy failed...");
        assertTrue(policyValidation.isPolicyAvailable(policyGetResponse, policyName, policyVersion));
        log.info("Policy Validated successfully...");
    }

    /**
     * get the policy from the policy list and deploy it if not deployed. Test
     * method will fail if policy is not available and if already deployed.
     */
    @When("^CL XNF Restart policy deployed^")
    public void deployXNFRestartPolicy() {
        log.info("Deploy policy...");
        Response policyGetResponse = policyValidation.getPolicy();
        assertNotNull(policyGetResponse, "Get policy failed...");
        assertEquals(200, policyGetResponse.getStatusCode(), "Get policy failed...");
        assertTrue(policyValidation.isPolicyAvailable(policyGetResponse, policyName, policyVersion),
                "Policy not available...");
        assertFalse(policyValidation.isPolicyDeployed(policyGetResponse, policyName, policyVersion),
                "Existing policy already deployed/active...");
        Response deployPolicyResponse = policyValidation.deployPolicy(policyName, policyVersion);
        assertNotNull(deployPolicyResponse);
        assertEquals(202, deployPolicyResponse.getStatusCode(), "Policy deploy failed...");
        policyGetResponse = policyValidation.getPolicy();
        assertNotNull(policyGetResponse, "Get policy failed...");
        assertEquals(200, policyGetResponse.getStatusCode(), "Get policy failed...");
        assertTrue(policyValidation.isPolicyDeployed(policyGetResponse, policyName, policyVersion),
                "Policy deployment failed...");
        log.info("Policy deployed successfully...");
    }

    /***
     * Get the policy ,undeploy it if already deployed(ACTIVE state)
     **/
    @And("^Undeploy CL XNF Restart Policy^") 
    public void undeployPolicy() {
        log.info("undeploy policy...");
        Response policyGetResponse = policyValidation.getPolicy();
        assertNotNull(policyGetResponse, "Get policy failed...");
        assertEquals(200, policyGetResponse.getStatusCode(), "Get policy failed...");
        assertTrue(policyValidation.isPolicyAvailable(policyGetResponse, policyName, policyVersion),
                "Policy not available...");
        assertTrue(policyValidation.isPolicyDeployed(policyGetResponse, policyName, policyVersion),
                "Policy not active/not deployed...");
        Response undeployPolicyResponse = policyValidation.undeployPolicy(policyName, policyVersion);
        assertNotNull(undeployPolicyResponse);
        assertEquals(202, undeployPolicyResponse.getStatusCode(), "undeploy policy failed...");
        policyGetResponse = policyValidation.getPolicy();
        assertNotNull(policyGetResponse, "Get policy failed...");
        assertEquals(200, policyGetResponse.getStatusCode());
        assertFalse(policyValidation.isPolicyDeployed(policyGetResponse, policyName, policyVersion),
                "Policy undeployment failed...");
        log.info("Policy undeployed successfully...");
    }

    @And("^Delete CL XNF Restart Policy^")
    public void deletePolicy() {
        log.info("Delete policy...");
        Response policyGetResponse = policyValidation.getPolicy();
        assertNotNull(policyGetResponse, "Get policy failed...");
        assertEquals(200, policyGetResponse.getStatusCode(), "Get policy failed...");
        assertTrue(policyValidation.isPolicyAvailable(policyGetResponse, policyName, policyVersion),
                "Policy not available...");
        Response policyDeleteResponse = policyValidation.deletePolicy(policyName, policyVersion);
        assertNotNull(policyDeleteResponse, "Policy delete failed...");
        assertEquals(200, policyDeleteResponse.getStatusCode(), "Policy delete failed...");
        policyGetResponse = policyValidation.getPolicy();
        assertNotNull(policyGetResponse);
        assertEquals(200, policyGetResponse.getStatusCode(), "Get policy failed...");
        assertFalse(policyValidation.isPolicyAvailable(policyGetResponse, policyName, policyVersion),
                "Policy not deleted...");
        log.info("Policy delete successfully...");
    }

}
