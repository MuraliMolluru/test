
package de.telekom.onap.oran.closedloop.steps;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertTrue;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import de.telekom.onap.dcae.vescollector.model.VesEvent;
import de.telekom.onap.oran.kafka.application.RestAssuredClient;
import de.telekom.onap.oran.kafka.configuration.Configuration;
import de.telekom.onap.oran.kafka.producer.WritePMMessageToKafka;
import de.telekom.onap.oran.kafka.util.DmaapMessageValidation;

public class CLLockUnlockCellSteps {
	private static final Logger log = LoggerFactory.getLogger(CLLockUnlockCellSteps.class);
	WritePMMessageToKafka pmMessageToKafka;
	private DmaapMessageValidation dmaapMessageValidation = null;
	private String measObjInstId = "";
	private RestAssuredClient assuredClient = null;

	
	public void setUp() {
		pmMessageToKafka = new WritePMMessageToKafka();
		assuredClient = new RestAssuredClient();
		dmaapMessageValidation = new DmaapMessageValidation(assuredClient);
	}


	public void testSendGuardPmMessage() {
		String kafkaPerfTopic = Configuration.getConfiguration().getKafkaPerfTopic();
		pmMessageToKafka.sendGuardPmMessage();
		VesEvent vesDownEvent = pmMessageToKafka.getVesEvent();
		String expectedEventId = vesDownEvent.getEvent().getCommonEventHeader().getEventId();
		measObjInstId = dmaapMessageValidation.getMeasObjInstId(vesDownEvent);
		String actualEventId = dmaapMessageValidation.validateMessage(kafkaPerfTopic, expectedEventId);
		assertEquals(expectedEventId, actualEventId);
	}


	public void testSendOnsetPmMessage() {

		try {
			Thread.sleep(35000);
		} catch (InterruptedException e2) {
			e2.printStackTrace();
		}
		String kafkaPerfTopic = Configuration.getConfiguration().getKafkaPerfTopic();
		pmMessageToKafka.sendOnsetPmMessage();
		VesEvent vesDownEvent = pmMessageToKafka.getVesEvent();
		String expectedEventId = vesDownEvent.getEvent().getCommonEventHeader().getEventId();
		String actualEventId = dmaapMessageValidation.validateMessage(kafkaPerfTopic, expectedEventId);
		assertEquals(expectedEventId, actualEventId);

	}


	public void testOnsetPmPolicyTrigger() {
		log.info("PM ONSET Policy message...");
		assertTrue(dmaapMessageValidation.isValidatePmPolicyMessage(measObjInstId, "ONSET"));
	}


	public void testSendAbatedPmMessage() {
		String kafkaPerfTopic = Configuration.getConfiguration().getKafkaPerfTopic();
		pmMessageToKafka.sendAbatedPmMessage();
		VesEvent vesDownEvent = pmMessageToKafka.getVesEvent();
		String expectedEventId = vesDownEvent.getEvent().getCommonEventHeader().getEventId();
		String actualEventId = dmaapMessageValidation.validateMessage(kafkaPerfTopic, expectedEventId);
		assertEquals(expectedEventId, actualEventId);
	}


	public void testAbatedPmPolicyTrigger() {
		log.info("PM ABATED Policy message...");
		assertTrue(dmaapMessageValidation.isValidatePmPolicyMessage(measObjInstId, "ABATED"));
	}
}
