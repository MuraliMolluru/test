#!/bin/bash

#DMaaP Message Router
keytool -delete -noprompt -keystore .keystore -storepass changeme -alias ves-collector
keytool -import -noprompt -keystore .keystore -storepass changeme -alias ves-collector -file dcae -trustcacerts

