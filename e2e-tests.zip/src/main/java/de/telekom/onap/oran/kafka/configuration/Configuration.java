
package de.telekom.onap.oran.kafka.configuration;

import java.io.FileInputStream;
import java.util.Properties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 * @author SH00721601
 *
 */
/**
 * @author SH00721601
 *
 */
public class Configuration {

	private static final Logger log = LoggerFactory.getLogger(Configuration.class);
	private String kafkaFaultTopic = "unauthenticated.SEC_FAULT_OUTPUT";
	private String kafkaPerfTopic = "unauthenticated.VES_PERF3GPP_OUTPUT";
	private String boostrapServers = "localhost:9093";
	private String securityProtocol = "SASL_PLAINTEXT";
	private String saslMechanism = "PLAIN";
	private String saslJaasConfig = "org.apache.kafka.common.security.plain.PlainLoginModule required username=\"admin\" password=\"admin_secret\";";
	private String vesCollectorHost = "10.42.10.132";
	private int vesCollectorPort = 30417;
	private String vesCollectorProtocol = "https";
	private String basicAuthUsername = "sample1";
	private String basicAuthPassword = "sample1";
	private int numberOfGuardMessages;
	private int numberOfAbateddMessages;
	private int numberOfOnsetMessages;
	private String envName;
	private String msbUrl;
	private String dmaapUrl;

	private String ruleUrl;
	private String ruleName;
	private String ruleLoopControlName;
	private String ruleEnabled;
	private String ruleDescription;
	private String ruleContent;

	private String policyUserName;
	private String policyPassword;
	private String policyUiDns;
	private String policyName;
	private String policyVersion;
	private String policyFileName;
	private Long sleepTime = 1000L;

	private static final Configuration configuration = new Configuration();

	private Configuration() {

		Properties p = new Properties();
		try {
			ClassLoader classLoader = getClass().getClassLoader();
			envName = System.getProperty("env", "tesla-dev");
			log.info("Configuration selected:" + envName);
			String fileName = classLoader.getResource(envName + "-application.properties").getFile();
			p.load(new FileInputStream(fileName));

			vesCollectorHost = p.getProperty("onap.ves.host", "localhost");
			vesCollectorPort = Integer.parseInt(p.getProperty("onap.ves.port", "8080"));
			vesCollectorProtocol = p.getProperty("onap.ves.protocol", "https");

			basicAuthUsername = p.getProperty("onap.ves.basicAuth.username", "sample1");
			basicAuthPassword = p.getProperty("onap.ves.basicAuth.password", "sample1");

			boostrapServers = p.getProperty("onap.kafka.boostrapServers");
			securityProtocol = p.getProperty("onap.kafka.security.protocol");
			saslMechanism = p.getProperty("onap.kafka.sasl.mechanism");
			saslJaasConfig = p.getProperty("onap.kafka.sasl.jaas.config");

			kafkaFaultTopic = p.getProperty("onap.kafka.fault.topic");

			kafkaPerfTopic = p.getProperty("onap.kafka.perf.topic");

			sleepTime = Long.parseLong(p.getProperty("sleepTime", "1000"));

			numberOfGuardMessages = Integer.parseInt(p.getProperty("numberOfGuardMessages", "0"));
			numberOfOnsetMessages = Integer.parseInt(p.getProperty("numberOfOnsetMessaages", "0"));
			numberOfAbateddMessages = Integer.parseInt(p.getProperty("numberOfAbateddMessages", "0"));

			msbUrl = p.getProperty("msb.url");
			dmaapUrl = p.getProperty("dmaap.url");

			ruleUrl = p.getProperty("rule.url");
			ruleName = p.getProperty("rule.name");
			ruleLoopControlName = p.getProperty("rule.loopcontrolname");
			ruleContent = p.getProperty("rule.content");
			ruleEnabled = p.getProperty("rule.enabled");
			ruleDescription = p.getProperty("rule.description");

			policyUserName = p.getProperty("policy.userName", "demo");
			policyPassword = p.getProperty("policy.password", "demo123456!");
			policyUiDns = p.getProperty("policy.ui.dns");
			policyName = p.getProperty("policy.name", "org.onap.policy.restartXNF");
			policyVersion = p.getProperty("policy.version", "1.0.0");
			policyFileName = p.getProperty("policy.fileName");

		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
	}

	public String getRuleUrl() {
		return ruleUrl;
	}

	public String getRuleName() {
		return ruleName;
	}

	public String getRuleLoopControlName() {
		return ruleLoopControlName;
	}

	public String getRuleEnabled() {
		return ruleEnabled;
	}

	public String getRuleDescription() {
		return ruleDescription;
	}

	public String getRuleContent() {
		return ruleContent;
	}

	public String getBasicAuthUsername() {
		return basicAuthUsername;
	}

	public String getBasicAuthPassword() {
		return basicAuthPassword;
	}

	public String getVesCollectorHost() {
		return vesCollectorHost;
	}

	public int getVesCollectorPort() {
		return vesCollectorPort;
	}

	public String getVesCollectorProtocol() {
		return vesCollectorProtocol;
	}

	public String getKafkaFaultTopic() {
		return kafkaFaultTopic;
	}

	public String getKafkaPerfTopic() {
		return kafkaPerfTopic;
	}

	public String getBoostrapServers() {
		return boostrapServers;
	}

	public String getSecurityProtocol() {
		return securityProtocol;
	}

	public String getSaslMechanism() {
		return saslMechanism;
	}

	public String getSaslJaasConfig() {
		return saslJaasConfig;
	}

	public static Configuration getConfiguration() {
		return configuration;
	}

	public int getNumberOfGuardMessages() {
		return numberOfGuardMessages;
	}

	public int getNumberOfAbateddMessages() {
		return numberOfAbateddMessages;
	}

	public int getNumberOfOnsetMessages() {
		return numberOfOnsetMessages;
	}

	public Long getSleepTime() {
		return sleepTime;
	}

	public String getEnvName() {
		return envName;
	}

	public String getMsbUrl() {
		return msbUrl;
	}

	public String getDmaapUrl() {
		return dmaapUrl;
	}

	public String getPolicyUiDns() {
		return policyUiDns;
	}

	public String getPolicyUserName() {
		return policyUserName;
	}

	public String getPolicyPassword() {
		return policyPassword;
	}

	public String getPolicyName() {
		return policyName;
	}

	public String getPolicyVersion() {
		return policyVersion;
	}

	public String getPolicyFileName() {
		return policyFileName;
	}

	@Override
	public String toString() {
		return "Configuration [kafkaFaultTopic=" + kafkaFaultTopic + ", kafkaPerfTopic=" + kafkaPerfTopic
				+ ", boostrapServers=" + boostrapServers + ", securityProtocol=" + securityProtocol + ", saslMechanism="
				+ saslMechanism + ", saslJaasConfig=" + saslJaasConfig + ", vesCollectorHost=" + vesCollectorHost
				+ ", vesCollectorPort=" + vesCollectorPort + ", vesCollectorProtocol=" + vesCollectorProtocol
				+ ", basicAuthUsername=" + basicAuthUsername + ", basicAuthPassword=" + basicAuthPassword
				+ ", numberOfGuardMessages=" + numberOfGuardMessages + ", numberOfAbateddMessages="
				+ numberOfAbateddMessages + ", numberOfOnsetMessages=" + numberOfOnsetMessages + ", envName=" + envName
				+ ", msbUrl=" + msbUrl + ", dmaapUrl=" + dmaapUrl + ", ruleUrl=" + ruleUrl + ", ruleName=" + ruleName
				+ ", ruleLoopControlName=" + ruleLoopControlName + ", ruleEnabled=" + ruleEnabled + ", ruleDescription="
				+ ruleDescription + ", ruleContent=" + ruleContent + ", policyUserName=" + policyUserName
				+ ", policyPassword=" + policyPassword + ", policyUiDns=" + policyUiDns + ", policyName=" + policyName
				+ ", policyVersion=" + policyVersion + ", policyFileName=" + policyFileName + ", sleepTime=" + sleepTime
				+ "]";
	}

}
