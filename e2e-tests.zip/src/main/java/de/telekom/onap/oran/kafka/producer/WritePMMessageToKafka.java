
package de.telekom.onap.oran.kafka.producer;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import de.telekom.onap.dcae.vescollector.model.VesEvent;
import de.telekom.onap.oran.kafka.configuration.Configuration;
import java.io.File;
import java.io.IOException;
import java.util.Properties;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.common.serialization.StringSerializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class WritePMMessageToKafka {

    Properties properties = null;
    KafkaProducer<String, String> producer = null;
    ClassLoader classLoader = null;
    VesEvent vesEvent = null;
    Configuration configuration = null;
    private static final Logger log = LoggerFactory.getLogger(WritePMMessageToKafka.class);

    /**
     * Method to Sending PM fault message to kafka.
     */
    public WritePMMessageToKafka() {
        configuration = Configuration.getConfiguration();
        log.info("Configuration data:" + configuration);
        classLoader = getClass().getClassLoader();
        properties = new Properties();
        properties.setProperty(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG,
                Configuration.getConfiguration().getBoostrapServers());
        properties.setProperty(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
        properties.setProperty(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
        properties.setProperty("security.protocol", Configuration.getConfiguration().getSecurityProtocol());
        properties.setProperty("sasl.mechanism", Configuration.getConfiguration().getSaslMechanism());
        properties.setProperty("sasl.jaas.config", Configuration.getConfiguration().getSaslJaasConfig());
        producer = new KafkaProducer<String, String>(properties);

    }

    /**
     * Method to getting ves Events from path gives as parameter.
     */
    public VesEvent getVesEvent(String pathName) {
        VesCollectorHandler vesCollectorHandler = new VesCollectorHandler();
        File srcFile = null;
        ObjectMapper mapper = vesCollectorHandler.getVesCollectorApiClient().getObjectMapper();
        srcFile = new File(pathName);
        VesEvent event = null;
        try {
            event = mapper.readValue(srcFile, new TypeReference<VesEvent>() {});
        } catch (IOException e) {
            log.error(e.getMessage(),e);
        }
        return event;
    }
    
    public VesEvent getVesEvent() {
        return vesEvent;
    }

    /**
     * Method to Sending vesEvents to kafka producer.
     */
    public void sendMsg(KafkaProducer<String, String> producer, VesEvent vesEvent) {
        ObjectMapper mapper = new ObjectMapper();
        try {
            String json = mapper.writeValueAsString(vesEvent);
            // create a producer record
            ProducerRecord<String, String> record =
                    new ProducerRecord<String, String>(Configuration.getConfiguration().getKafkaPerfTopic(), json);
            producer.send(record);
            //Future<RecordMetadata> response = producer.send(record);
        } catch (Exception e) {
            log.error(e.getMessage(),e);
        }
    }

    /**
     * Method to Sending GuardPM message to kafka producer.
     */
    public void sendGuardPmMessage() {
        try {
            String fileName = "vesEvents/vesPerf3gppGUARD.json";
            KafkaProducer<String, String> producer = getProducer();
            vesEvent = getVesEvent(classLoader.getResource(fileName).getFile());
            for (int i = 1; i <= configuration.getNumberOfGuardMessages(); i++) {
                log.info("Testing:Sending Guard message...");
                sendMsg(producer, vesEvent);
            }
        } catch (Exception e) {
            log.error(e.getMessage(),e);
        }

    }

    /**
     * Method to Sending OnsetPM message to kafka producer.
     */
    public void sendOnsetPmMessage() {
        try {
            String fileName = "vesEvents/vesPerf3gppONSET.json";
            KafkaProducer<String, String> producer = getProducer();
            vesEvent = getVesEvent(classLoader.getResource(fileName).getFile());
            for (int i = 1; i <= configuration.getNumberOfOnsetMessages(); i++) {
                log.info("Sending Onset message...");
                sendMsg(producer, vesEvent);
            }
        } catch (Exception e) {
            log.error(e.getMessage(),e);
        }
    }

    /**
     * Method to Sending AbatedPM message to kafka producer.
     */
    public void sendAbatedPmMessage() {
        try {
            String fileName = "vesEvents/vesPerf3gppABATED.json";
            KafkaProducer<String, String> producer = getProducer();
            vesEvent = getVesEvent(classLoader.getResource(fileName).getFile());
            for (int i = 1; i <= configuration.getNumberOfAbateddMessages(); i++) {
                log.info("Sending Abated message...");
                sendMsg(producer, vesEvent);
            }
        } catch (Exception e) {
            log.error(e.getMessage(),e);
        }
    }

    public Properties getProperties() {
        return properties;
    }

    public KafkaProducer<String, String> getProducer() {
        return producer;
    }

}
