/**
 * Copyright 2017-2020 ZTE Corporation.

 * Licensed under the Apache License, Version 2.0 (the "License"); you may not use this file except
 * in compliance with the License. You may obtain a copy of the License at

 * http://www.apache.org/licenses/LICENSE-2.0

 * Unless required by applicable law or agreed to in writing, software distributed under the License
 * is distributed on an "AS IS" BASIS, WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express
 * or implied. See the License for the specific language governing permissions and limitations under
 * the License.
 */

package de.telekom.onap.oran.rule.entity;

import de.telekom.onap.oran.kafka.application.RestAssuredClient;
import de.telekom.onap.oran.kafka.configuration.Configuration;
import groovy.util.logging.Slf4j;
import io.restassured.response.Response;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import org.json.JSONArray;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Slf4j
public class RuleManagement {

    private RestAssuredClient resClient = null;
    private Configuration config = null;
    private final Logger log = LoggerFactory.getLogger(RuleManagement.class);

    private String url = "/api/holmes-rule-mgmt/v1/rule";
    private String ipPort = "";
    private String ruleId = "";
    private String ruleName = "";
    private boolean isUrlWorking = false;

    /**
     * Method To Create RestAssuredClient Object As RuleManagement Object Created.
     */
    public RuleManagement() {

        resClient = new RestAssuredClient();
        config = Configuration.getConfiguration();

        ipPort = config.getRuleUrl();
        ruleName = config.getRuleName();

    }

    /**
     * Method To Validate URL.
     */
    public boolean isUrlValid() {
        if (!ipPort.equals("")) {

            url = ipPort + url;
            log.info("URL : - " + url);

            try {

                isUrlWorking = resClient.get(url).statusCode() == 200;

            } catch (Exception e) {
                log.error("URL NOT WORKING !." + e);
            }

        } else {
            log.error("Invalid IP & PORT ");
        }
        return isUrlWorking;
    }

    /**
     * Method To Get Rule Id.
     */
    public String getRuleId() {
        String ruleID = ruleId;
        if (isUrlWorking && ruleID.equals("")) {
            Response res = getRules();
            if (res.getStatusCode() == 200) {
                try {
                    JSONObject rulesObj = new JSONObject(res.asString());
                    int totalCount = rulesObj.getInt("totalCount");
                    if (totalCount > 0) {
                        JSONArray rules = new JSONArray(rulesObj.getJSONArray("correlationRules"));

                        for (Object rule : rules) {
                            if (rule instanceof JSONObject) {
                                JSONObject temp = (JSONObject) rule;
                                if (temp.getString("ruleName").equals(ruleName)) {
                                    ruleID = temp.getString("ruleId");
                                    break;
                                }
                            }
                        }

                    } else {
                        log.error("No Rules Availble To Find Rule Id.");
                    }

                } catch (Exception e) {
                    log.error("Invalid JSON Response : - " + e);
                }
            }
        }
        return ruleID;
    }

    /**
     * Method To Get Rule Content From File.
     */
    private StringBuilder getRuleFileContent() {

        StringBuilder ruleContent = new StringBuilder();

        File file = new File(RuleManagement.class.getClassLoader().getResource("./ruleFiles/TNAP_RULE.drl").getFile());
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {

            String line;
            while ((line = reader.readLine()) != null) {
                ruleContent.append(line + "\n");
            }
        } catch (FileNotFoundException e) {
            log.error("File Not Found : - " + e);
        } catch (IOException e) {
            log.error("IO Exception : - " + e);
        }

        return ruleContent;
    }

    /**
     * Method To Rule Data In JSON As String.
     */
    private JSONObject getRuleData(String ruleID) {

        JSONObject obj = new JSONObject();

        String ruleContent = getRuleFileContent().toString();
        // String ruleContent = config.getRuleContent();

        if (ruleID.equals("")) {

            obj.put("ruleName", config.getRuleName());
            obj.put("loopControlName", config.getRuleLoopControlName());
            obj.put("content", ruleContent);
            obj.put("enabled", config.getRuleEnabled());
            obj.put("description", config.getRuleDescription());

        } else {

            obj.put("ruleId", ruleID);
            obj.put("ruleName", config.getRuleName());
            obj.put("loopControlName", config.getRuleLoopControlName());
            obj.put("content", ruleContent);
            obj.put("enabled", config.getRuleEnabled());
            obj.put("description", "SCTP-DOWN_New");

        }

        // log.info(obj.toString());

        return obj;
    }

    /**
     * Method To Get All Rules In Holmes Engine By Calling GET Method.
     */
    public Response getRules() {

        return resClient.get(url);

    }

    /**
     * Method To Add Rule In Holmes Engine By Calling PUT Method And Provide Data As JSON Received In Parameter.
     */
    public boolean addRule() {

        boolean flag = false;

        if (isUrlWorking) {

            JSONObject ruleData = getRuleData("");

            Response retObj = resClient.put(ruleData.toString(), url);

            log.info("Response : - " + retObj.asString());

            if (retObj.getStatusCode() == 200) {

                try {
                    JSONObject resObj = new JSONObject(retObj.asString());
                    ruleId = resObj.getString("ruleId");

                    if (!ruleId.equals("")) {
                        flag = true;
                    }

                } catch (Exception e) {
                    log.error("Invalid Response No Rule Id Availble.");
                }
            }

        }
        return flag;

    }

    /**
     * Method To Update Rule In Holmes Engine By Calling POST Method And Provide Data As JSON Received In Parameter.
     */
    public boolean updateRule() {

        boolean flag = false;

        String ruleID = getRuleId();

        if (!ruleID.equals("") && isUrlWorking) {

            JSONObject ruleData = getRuleData(ruleID);

            Response retObj = resClient.post(ruleData.toString(), url);

            log.info("Response : - " + retObj.asString());

            if (retObj.getStatusCode() == 200) {
                flag = true;
            }

        } else {
            log.error("No Rule Id Availabe To Update.");
        }

        return flag;
    }

    /**
     * Method To Delete Rule From Holmes Engine By Calling Delete Method And Provide Rule Id Received In Parameter.
     */
    public boolean deleteRule() {

        boolean flag = false;

        String ruleID = getRuleId();

        if (!ruleID.equals("") && isUrlWorking) {

            String deleteUrl = url + "/" + ruleID;
            log.info("Delete Url : - " + deleteUrl);

            Response retObj = resClient.delete("", deleteUrl);

            log.info("Response : - " + retObj.asString());

            if (retObj.getStatusCode() == 200) {
                flag = true;
            }

        } else {
            log.error("No Rule Id Availabe To Delete.");
        }

        return flag;
    }

}
