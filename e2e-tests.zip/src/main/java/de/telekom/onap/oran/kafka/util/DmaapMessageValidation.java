
package de.telekom.onap.oran.kafka.util;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import de.telekom.onap.dcae.vescollector.model.VesEvent;
import de.telekom.onap.oran.kafka.application.PolicyNotificationData;
import de.telekom.onap.oran.kafka.application.RestAssuredClient;
import de.telekom.onap.oran.kafka.configuration.Configuration;
import io.restassured.response.Response;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class DmaapMessageValidation {
	private static final Logger log = LoggerFactory.getLogger(DmaapMessageValidation.class);
	RestAssuredClient restAssuredClient = null;
	private String closedLoopControlName = "";

	public DmaapMessageValidation(RestAssuredClient assuredClient) {
		restAssuredClient = assuredClient;
	}

	/**
	 * Method to Validate Event Id On URL Given As Parameter.
	 */
	public String validateMessage(String topicName, String expectedEventId) {
		String url = Configuration.getConfiguration().getDmaapUrl() + "/events/" + topicName
				+ "/CLT/C10?timeout=15000&limit=100";
		log.info("Dmaap url====>>>>" + url);
		boolean matchFound = false;
		String actualEventId = "";
		Timestamp startTime = new Timestamp(System.currentTimeMillis());
		while (true) {
			try {
				List<String> dmaapData = getDmaapData(url);
				if (dmaapData != null && !dmaapData.isEmpty()) {
					for (String event : dmaapData) {
						JsonObject convertToJsonObject = new Gson().fromJson(event, JsonObject.class);
						actualEventId = convertToJsonObject.getAsJsonObject("event")
								.getAsJsonObject("commonEventHeader").get("eventId").getAsString();
						if (actualEventId.equals(expectedEventId)) {
							matchFound = true;
							log.info(event);
							break;
						}
					}
					if (matchFound) {
						break;
					}
				}
				Timestamp newTime = new Timestamp(System.currentTimeMillis());
				if ((newTime.getTime() - startTime.getTime()) > 180000) {
					break;
				}

			} catch (Exception e) {
				try {
					log.error(e.getMessage(), e);
					Thread.sleep(60000);
				} catch (InterruptedException e1) {
					log.error(e1.getMessage(), e1);
				}
			}

		}
		return actualEventId;
	}

	/**
	 * Method to Validate PM Policy Message On URL Given As Parameter.
	 */
	public boolean isValidatePmPolicyMessage(String expectedValue, String expectedClosedLoopEventStatus) {
		String url = Configuration.getConfiguration().getDmaapUrl()
				+ "/events/unauthenticated.DCAE_CL_OUTPUT/CLT/C10?timeout=15000&limit=100";
		log.info("Dmaap url====>>>>" + url);
		String actualValue = "";
		boolean matchFound = false;
		Timestamp startTime = new Timestamp(System.currentTimeMillis());
		while (true) {
			try {
				List<String> dmaapData = getDmaapData(url);
				if (dmaapData != null && !dmaapData.isEmpty()) {
					for (String policyData : dmaapData) {
						JsonObject convertToJsonObject = new Gson().fromJson(policyData, JsonObject.class);
						log.info(convertToJsonObject.toString());
						JsonObject additionalEventParams = convertToJsonObject.getAsJsonObject("additionalEventParams");
						if (additionalEventParams.size() > 0) {
							actualValue = convertToJsonObject.getAsJsonObject("additionalEventParams")
									.get("cellIdentity").getAsString();
						}
						log.info("Policy value:" + actualValue);
						String actualClosedLoopEventStatus = convertToJsonObject.get("closedLoopEventStatus")
								.getAsString();
						if (actualValue.equals(expectedValue)
								&& actualClosedLoopEventStatus.equals(expectedClosedLoopEventStatus)) {
							matchFound = true;
							break;
						}
					}
					if (matchFound) {
						break;
					}

				}
				Timestamp newTime = new Timestamp(System.currentTimeMillis());
				if ((newTime.getTime() - startTime.getTime()) > 180000) {
					break;
				}
			} catch (Exception e) {
				try {
					log.error(e.getMessage(), e);
					Thread.sleep(60000);
				} catch (InterruptedException e1) {
					log.error(e1.getMessage(), e1);
				}
			}
		}
		return matchFound;
	}

	/**
	 * Method to Validate FM Policy Message On URL Given As Parameter.
	 */
	public boolean isValidateFmPolicy(String expectedValue, String expectedClosedLoopEventStatus) {
		String url = Configuration.getConfiguration().getDmaapUrl()
				+ "/events/unauthenticated.DCAE_CL_OUTPUT/CLT/C10?timeout=15000&limit=100";
		log.info("Dmaap url====>>>>" + url);
		String actualValue = "";

		boolean matchFound = false;
		Timestamp startTime = new Timestamp(System.currentTimeMillis());
		while (true) {
			try {
				List<String> dmaapData = getDmaapData(url);
				if (dmaapData != null && !dmaapData.isEmpty()) {
					for (String policyData : dmaapData) {
						JsonObject convertToJsonObject = new Gson().fromJson(policyData, JsonObject.class);
						actualValue = convertToJsonObject.get("closedLoopEventClient").getAsString();
						String actualClosedLoopEventStatus = convertToJsonObject.get("closedLoopEventStatus")
								.getAsString();
						if (actualValue.equals(expectedValue)
								&& actualClosedLoopEventStatus.equals(expectedClosedLoopEventStatus)) {
							log.info("Policy Data=====>>>" + convertToJsonObject);
							if (actualClosedLoopEventStatus.equals("ONSET")) {
								closedLoopControlName = convertToJsonObject.get("closedLoopControlName").getAsString();
								matchFound = isAAIDataValid(convertToJsonObject);
							} else {
								matchFound = true;
							}
							break;
						}
					}
					if (matchFound) {
						break;
					}

				}
				Timestamp newTime = new Timestamp(System.currentTimeMillis());
				if ((newTime.getTime() - startTime.getTime()) > 180000) {
					break;
				}
			} catch (Exception e) {
				try {
					log.error(e.getMessage(), e);
					Thread.sleep(60000);
				} catch (InterruptedException e1) {
					log.error(e1.getMessage(), e1);
				}
			}
		}
		return matchFound;
	}

	/**
	 * Method to GET Policy Notification From URL Given As Parameter.
	 */
	public PolicyNotificationData getPolicyNotificationData() {
		String url = Configuration.getConfiguration().getDmaapUrl()
				+ "/events/POLICY-CL-MGT/CLT/C10?timeout=15000&limit=100";
		log.info("Dmaap url====>>>>" + url);
		PolicyNotificationData policyNotificationData = null;
		Timestamp startTime = new Timestamp(System.currentTimeMillis());
		while (true) {
			try {
				List<String> dmaapData = getDmaapData(url);
				if (dmaapData != null && !dmaapData.isEmpty()) {
					for (String policyNotification : dmaapData) {
						JsonObject convertToJsonObject = new Gson().fromJson(policyNotification, JsonObject.class);
						if (convertToJsonObject != null) {
							log.info("Policy Notification======>>>>" + convertToJsonObject);
							JsonElement jsonHistoryElement = convertToJsonObject.get("history");
							if (jsonHistoryElement != null && jsonHistoryElement.isJsonArray()) {
								JsonArray histories = jsonHistoryElement.getAsJsonArray();
								log.info("Policy history======>>>>");
								for (JsonElement historyData : histories) {
									JsonElement outCome = historyData.getAsJsonObject().get("outcome");
									log.info("Policy outcome======>>>>");
									if (outCome != null && (outCome.getAsString().equals("Failure")
											|| outCome.getAsString().equals("Success"))) {
										log.info("Policy Notification======>>>>" + convertToJsonObject);
										policyNotificationData = new PolicyNotificationData();
										policyNotificationData
												.setActor(historyData.getAsJsonObject().get("actor").getAsString());
										policyNotificationData.setOperation(
												historyData.getAsJsonObject().get("operation").getAsString());
										policyNotificationData.setOutCome(outCome.getAsString());
										policyNotificationData.setClosedLoopControlName(
												convertToJsonObject.get("closedLoopControlName").getAsString());
									}
								}
							}
						}
					}
				}
				Timestamp newTime = new Timestamp(System.currentTimeMillis());
				if ((newTime.getTime() - startTime.getTime()) > 180000) {
					break;
				}
			} catch (Exception e) {
				try {
					log.error(e.getMessage(), e);
					Thread.sleep(60000);
				} catch (InterruptedException e1) {
					log.error(e1.getMessage(), e1);
				}
			}
		}
		return policyNotificationData;
	}

	@SuppressWarnings("unchecked")
	private List<String> getDmaapData(String url) {
		List<String> responseList = new ArrayList<String>();
		RestAssuredClient restAssuredClient = new RestAssuredClient();
		Response response = restAssuredClient.get(url);
		if (response.statusCode() == 200) {
			String asString = response.asString();
			responseList = new Gson().fromJson(asString, List.class);
		}
		return responseList;
	}

	private boolean isAAIDataValid(JsonObject policyJsonObject) {
		try {
			JSONObject responseJson = new JSONObject(policyJsonObject.toString());
			JSONObject aaiData = responseJson.getJSONObject("AAI");
			if (aaiData.isEmpty()) {
				return false;
			}
			if (aaiData.getString("generic-vnf.vnf-name").isEmpty()) {
				return false;
			}
			if (aaiData.getString("generic-vnf.is-closed-loop-disabled").isEmpty()) {
				return false;
			}
			if (aaiData.getString("vserver.vserver-id").isEmpty()) {
				return false;
			}
			if (aaiData.getString("vserver.vserver-name").isEmpty()) {
				return false;
			}
			if (aaiData.getString("generic-vnf.vnf-id").isEmpty()) {
				return false;
			}
		} catch (JSONException e) {
			log.error(e.getMessage(), e);
			return false;
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			return false;
		}
		return true;
	}

	public String getClosedLoopControlName() {
		return closedLoopControlName;
	}

	public String getMeasObjInstId(VesEvent vesDownEvent) {
		String measObjInstId = "";
		try {
			measObjInstId = vesDownEvent.getEvent().getPerf3gppFields().getMeasDataCollection().getMeasInfoList().get(0)
					.getMeasValuesList().get(0).getMeasObjInstId();
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
		return measObjInstId;
	}
}
