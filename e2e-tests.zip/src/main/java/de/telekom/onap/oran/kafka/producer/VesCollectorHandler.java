
package de.telekom.onap.oran.kafka.producer;

import de.telekom.onap.dcae.vescollector.api.VesRestControllerApi;
import de.telekom.onap.dcae.vescollector.invoker.ApiClient;
import de.telekom.onap.dcae.vescollector.invoker.ApiException;
import de.telekom.onap.dcae.vescollector.invoker.ApiResponse;
import de.telekom.onap.dcae.vescollector.invoker.Configuration;
import de.telekom.onap.dcae.vescollector.model.VesEvent;
import java.net.http.HttpClient;
import java.time.Duration;
import java.util.Base64;

public class VesCollectorHandler {

    private ApiClient apiClient = null;
    private VesRestControllerApi vesControllerApi = null;
    //private static final Logger log = LoggerFactory.getLogger(VesCollectorHandler.class);

    /**
     * Default Constructor to Setting Initial Value.
     */
    public VesCollectorHandler() {
        // TODO: Better way?
        if (System.getProperty("javax.net.ssl.trustStore") == null) {
            System.setProperty("javax.net.ssl.trustStore", "src/main/resources/.keystore");
            System.setProperty("javax.net.ssl.trustStorePassword", "changeme");
        }
        System.setProperty("jdk.internal.httpclient.disableHostnameVerification", "true");
        // System.setProperty("javax.net.debug", "SSL");
        System.setProperty("jdk.httpclient.connectionPoolSize", "4");
        System.setProperty("jdk.http.auth.tunneling.disabledSchemes", "");
        apiClient = getApiClient();
        vesControllerApi = new VesRestControllerApi(apiClient);
    }

    private ApiClient getApiClient() {
        ApiClient defaultClient = Configuration.getDefaultApiClient();
        defaultClient.setHost(
                de.telekom.onap.oran.kafka.configuration.Configuration.getConfiguration().getVesCollectorHost());
        defaultClient.setPort(
                de.telekom.onap.oran.kafka.configuration.Configuration.getConfiguration().getVesCollectorPort());
        defaultClient.setScheme(
                de.telekom.onap.oran.kafka.configuration.Configuration.getConfiguration().getVesCollectorProtocol());
        defaultClient.setReadTimeout(Duration.ofMillis(60000));

        HttpClient.Builder builder = HttpClient.newBuilder();
        builder.version(HttpClient.Version.HTTP_2);
        defaultClient.setHttpClientBuilder(builder);

        defaultClient.setRequestInterceptor((b) -> {
            b.setHeader("Authorization", basicAuth(
                    de.telekom.onap.oran.kafka.configuration.Configuration.getConfiguration().getBasicAuthUsername(),
                    de.telekom.onap.oran.kafka.configuration.Configuration.getConfiguration().getBasicAuthPassword()));
        });

        return defaultClient;
    }

    private static String basicAuth(String username, String password) {
        return "Basic " + Base64.getEncoder().encodeToString((username + ":" + password).getBytes());
    }

    public ApiResponse<Void> mainPageUsingGetWithHttpInfo() throws ApiException {
        return vesControllerApi.mainPageUsingGETWithHttpInfo();
    }

    public ApiResponse<Void> receiveEventV7WithHttpInfo(VesEvent jsonPayload) throws ApiException {
        return vesControllerApi.receiveEventUsingPOST10WithHttpInfo(jsonPayload);
    }

    public ApiClient getVesCollectorApiClient() {
        return apiClient;
    }
}
