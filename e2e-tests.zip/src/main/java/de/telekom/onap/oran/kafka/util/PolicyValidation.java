package de.telekom.onap.oran.kafka.util;

import java.io.InputStream;
import java.sql.Timestamp;

import org.json.JSONArray;
import org.json.JSONObject;
import org.json.JSONTokener;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import de.telekom.onap.oran.kafka.application.RestAssuredClient;
import de.telekom.onap.oran.kafka.configuration.Configuration;
import io.restassured.response.Response;

public class PolicyValidation {
	private final Logger log = LoggerFactory.getLogger(PolicyValidation.class);
	RestAssuredClient restAssuredClient = null;
	JSONObject policyDataToCreate = null;
	private String policyUiDns = Configuration.getConfiguration().getPolicyUiDns();
	private String policyFileName = Configuration.getConfiguration().getPolicyFileName();

	public PolicyValidation(RestAssuredClient assuredClient) {
		restAssuredClient = assuredClient;
	}

	public Response createPolicy(String policyName, String policyVersion) {
		String policyPostUrl = "https://" + policyUiDns
				+ "/restservices/clds/v2/policies/onap.policies.controlloop.operational.common.Drools/1.0.0/"
				+ policyName + "/" + policyVersion;
		Response postResponse = null;
		log.info("create url===>>>>" + policyPostUrl);
		JSONObject policyData = getPolicyData();
		log.info("Policy data======>>>>" + policyData);
		try {
			if (policyData != null) {
				postResponse = restAssuredClient.postWithCrendentials(policyData.toString(), policyPostUrl);

			} else {
				log.info("No policy data to create the policy....");
			}
		} catch (Exception e) {
			log.error("Policy create operation failed...", e);
		}
		return postResponse;

	}

	public Response deployPolicy(String policyName, String policyVersion) {
		Response deployResponse = null;
		try {
			String payLoad = "{\"PdpActions\":[\"POST/defaultGroup/drools/" + policyName + "/" + policyVersion + "\"]}";
			String policyDeployUrl = " https://" + policyUiDns + "/restservices/clds/v2/policies/pdpDeployment";
			log.info("deploy url===>>>>" + policyDeployUrl);
			deployResponse = restAssuredClient.putWithCredentials(payLoad, policyDeployUrl);
		} catch (Exception e) {
			log.info("policy deploy failed", e);
		}
		return deployResponse;
	}

	public Response undeployPolicy(String policyName, String policyVersion) {
		Response deployResponse = null;
		try {
			String payLoad = "{\"PdpActions\":[\"DELETE/defaultGroup/drools/" + policyName + "/" + policyVersion
					+ "\"]}";
			String policyDeployUrl = " https://" + policyUiDns + "/restservices/clds/v2/policies/pdpDeployment";
			log.info("undeploy url===>>>>" + policyDeployUrl);
			deployResponse = restAssuredClient.putWithCredentials(payLoad, policyDeployUrl);
		} catch (Exception e) {
			log.info("policy deploy failed", e);
		}
		return deployResponse;
	}

	public Response deletePolicy(String policyName, String policyVersion) {
		String deletePolicyUrl = "https://" + policyUiDns
				+ "/restservices/clds/v2/policies/onap.policies.controlloop.operational.common.Drools/1.0.0/"
				+ policyName + "/" + Configuration.getConfiguration().getPolicyVersion();
		Response response = null;
		log.info("delete url===>>>>" + deletePolicyUrl);
		try {
			response = restAssuredClient.deleteWithCredentails(deletePolicyUrl);
		} catch (Exception e) {
			log.error("Policy delete operation failed...", e);
		}
		return response;
	}

	public Response getPolicy() {
		String policyGetUrl = "https://" + policyUiDns + "/restservices/clds/v2/policies";
		Response response = null;
		log.info("get url===>>>>" + policyGetUrl);
		try {
			Timestamp startTime = new Timestamp(System.currentTimeMillis());
			while (true) {
				response = restAssuredClient.getWithCredentials(policyGetUrl);
				Timestamp newTime = new Timestamp(System.currentTimeMillis());
				if (response.getStatusCode() == 200 || (newTime.getTime() - startTime.getTime()) > 60000) {
					break;
				}
			}
		} catch (Exception e) {
			log.error("Policy get operation failed...", e);
		}
		return response;

	}

	public JSONObject getPolicyData() {
		if (policyDataToCreate == null) {
			InputStream openStream;
			try {
				openStream = getClass().getClassLoader().getResource("policies/" + policyFileName).openStream();
				JSONTokener jsonTokener = new JSONTokener(openStream);
				policyDataToCreate = new JSONObject(jsonTokener);
			} catch (Exception e) {
				log.error("Failed to read policy data from file...", e);
			}

		}
		return policyDataToCreate;
	}

	private JSONObject getPolicyAvailable(Response response, String policyName, String policyVersion) {
		JSONObject policyData = null;
		try {
			// log.info("Policy Data====>>>>" + response.asString());
			JSONObject jsonObject = new JSONObject(response.asString());
			JSONArray policyArray = jsonObject.getJSONArray("policies");
			for (int i = 0; i < policyArray.length(); i++) {
				Object policy = policyArray.get(i);
				if (policy instanceof JSONObject) {
					JSONObject object = (JSONObject) policy;
					JSONObject policyMetadata = object.getJSONObject("metadata");
					String availablePolicyName = policyMetadata.getString("policy-id");
					String availablePolicyVersion = policyMetadata.getString("policy-version");
					if (availablePolicyName.equals(policyName) && availablePolicyVersion.equals(policyVersion)) {
						policyData = object;
						return policyData;
					}
				}
			}
		} catch (Exception e) {
			log.error(e.getMessage(), e);
		}
		return policyData;
	}

	private String getPolicyDepolyStatus(Response response, String policyName, String policyVersion) {
		String policyDeployStatus = null;
		try {
			JSONObject policyAvailable = getPolicyAvailable(response, policyName, policyVersion);
			if (policyAvailable != null) {
				if (!policyAvailable.isNull("pdpGroupInfo")) {
					JSONArray pdpGroupInfoArray = policyAvailable.getJSONArray("pdpGroupInfo");
					for (Object object : pdpGroupInfoArray) {
						if (object instanceof JSONObject) {
							JSONObject object1 = (JSONObject) object;
							policyDeployStatus = object1.getJSONObject("defaultGroup").getString("pdpGroupState");
						}
					}
				}

			}
		} catch (Exception e) {
			log.error("pdpGroupInfo fetch failed... ", e);
		}

		return policyDeployStatus;
	}

	public boolean isPolicyAvailable(Response response, String policyName, String policyVersion) {
		JSONObject policyData = getPolicyAvailable(response, policyName, policyVersion);
		return policyData != null ? true : false;
	}

	public boolean isPolicyDeployed(Response response, String policyName, String policyVersion) {
		boolean isPolicyDeployed = false;
		String policyDeployStatus = getPolicyDepolyStatus(response, policyName, policyVersion);
		if (policyDeployStatus != null && policyDeployStatus.equals("ACTIVE")) {
			isPolicyDeployed = true;
		}
		return isPolicyDeployed;
	}
}
