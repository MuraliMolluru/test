
package de.telekom.onap.oran.kafka.producer;

import java.io.File;
import java.io.IOException;
import java.util.Properties;
import java.util.concurrent.Future;

import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.apache.kafka.common.serialization.StringSerializer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;

import de.telekom.onap.dcae.vescollector.model.VesEvent;
import de.telekom.onap.oran.kafka.configuration.Configuration;

public class WriteFaultMessageToKafka {
	Properties properties = null;
	KafkaProducer<String, String> producer = null;
	ClassLoader classLoader = null;
	VesEvent vesEvent = null;
	Configuration configuration = null;
	private static final Logger log = LoggerFactory.getLogger(WriteFaultMessageToKafka.class);

	/**
	 * Method to Sending FM fault message to kafka.
	 */
	public WriteFaultMessageToKafka() {
		configuration = Configuration.getConfiguration();
		log.info("Configuration data:" + configuration);
		classLoader = getClass().getClassLoader();
		properties = new Properties();
		properties.setProperty(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG,
				Configuration.getConfiguration().getBoostrapServers());
		properties.setProperty(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
		properties.setProperty(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName());
		properties.setProperty("security.protocol", Configuration.getConfiguration().getSecurityProtocol());
		properties.setProperty("sasl.mechanism", Configuration.getConfiguration().getSaslMechanism());
		properties.setProperty("sasl.jaas.config", Configuration.getConfiguration().getSaslJaasConfig());
		producer = new KafkaProducer<String, String>(properties);
	}

	/**
	 * Method to Sending vesEvents to kafka producer.
	 */
	public void sendMsg(KafkaProducer<String, String> producer, VesEvent vesEvent) {
		ObjectMapper mapper = new ObjectMapper();
		try {
			String json = mapper.writeValueAsString(vesEvent);
			ProducerRecord<String, String> record = new ProducerRecord<String, String>(
					Configuration.getConfiguration().getKafkaFaultTopic(), json);
			Future<RecordMetadata> response = producer.send(record);
			response.get();
			// RecordMetadata recordMetadata = response.get();
		} catch (Exception e) {
			log.error(e.getMessage(),e);
		}
	}

	/**
	 * Method to Sending first FM down message kafka producer.
	 */
	public void sendFmDownMessage_1() {
		try {
			String fileName = "vesEvents/VesFaultDown_cucp1.json";
			KafkaProducer<String, String> producer = getProducer();
			String file = classLoader.getResource(fileName).getFile();
			log.info("Sending FM down message..." + file);
			vesEvent = getVesEvent(file);
			sendMsg(producer, vesEvent);
			log.info("Sent FM down message...");
		} catch (Exception e) {
			log.error(e.getMessage(),e);
		}
	}

	/**
	 * Method to Sending second FM down message kafka producer.
	 */
	public void sendFmDownMessage_2() {
		try {
			String fileName = "vesEvents/VesFaultDown_cucp2.json";
			KafkaProducer<String, String> producer = getProducer();
			String file = classLoader.getResource(fileName).getFile();
			log.info("Sending FM down message..." + file);
			vesEvent = getVesEvent(file);
			sendMsg(producer, vesEvent);
			log.info("Sent FM down message...");
		} catch (Exception e) {
			log.error(e.getMessage(),e);
		}
	}

	/**
	 * Method to Sending first FM up message kafka producer.
	 */
	public void sendFmUpMessage_1() {
		try {
			String fileName = "vesEvents/VesFaultUP_cucp1.json";
			KafkaProducer<String, String> producer = getProducer();
			String file = classLoader.getResource(fileName).getFile();
			log.info("Sending FM up message..." + file);
			vesEvent = getVesEvent(file);
			sendMsg(producer, vesEvent);
			log.info("Sent FM up message...");
		} catch (Exception e) {
			log.error(e.getMessage(),e);
		}
	}

	/**
	 * Method to Sending second FM up message kafka producer.
	 */
	public void sendFmUpMessage_2() {
		try {
			String fileName = "vesEvents/VesFaultUP_cucp2.json";
			KafkaProducer<String, String> producer = getProducer();
			String file = classLoader.getResource(fileName).getFile();
			log.info("Sending FM up message..." + file);
			vesEvent = getVesEvent(file);
			sendMsg(producer, vesEvent);
			log.info("Sent FM up message...");
		} catch (Exception e) {
			log.error(e.getMessage(),e);
		}
	}

	/**
	 * Method to getting ves Events from path gives as parameter.
	 */
	public VesEvent getVesEvent(String pathName) {
		VesCollectorHandler vesCollectorHandler = new VesCollectorHandler();
		File srcFile = null;
		ObjectMapper mapper = vesCollectorHandler.getVesCollectorApiClient().getObjectMapper();
		srcFile = new File(pathName);
		VesEvent event = null;
		try {
			event = mapper.readValue(srcFile, new TypeReference<VesEvent>() {
			});
		} catch (IOException e) {
			log.error(e.getMessage(),e);
		}
		return event;
	}

	public VesEvent getVesEvent() {
		return vesEvent;
	}

//    /**
//     * Method to  checking holmes engine health check.
//     */
//    public int holmesEngineHealthCheck(String url) {
//        log.info("Checking holmes engine health check...");
//        DmaapResponse dmaapResponse = new DmaapResponse();
//        org.apache.http.HttpResponse httpResponse = null;
//        try {
//            httpResponse = dmaapResponse.get(url);
//        } catch (Exception e) {
//            log.error(e.getMessage());
//        }
//        return httpResponse != null ? httpResponse.getStatusLine().getStatusCode() : 0;
//    }
//
//    /**
//     * Method to checking holmes rule health check.
//     */
//    public int holmesRuleHealthCheck(String url) {
//        log.info("Checking holmes rule health check...");
//        DmaapResponse dmaapResponse = new DmaapResponse();
//        org.apache.http.HttpResponse httpResponse = null;
//        try {
//            httpResponse = dmaapResponse.get(url);
//        } catch (Exception e) {
//            log.error(e.getMessage());
//        }
//        return httpResponse != null ? httpResponse.getStatusLine().getStatusCode() : 0;
//    }

	public Properties getProperties() {
		return properties;
	}

	public KafkaProducer<String, String> getProducer() {
		return producer;
	}

	public void setProperties(Properties properties) {
		this.properties = properties;
	}

	public void setProducer(KafkaProducer<String, String> producer) {
		this.producer = producer;
	}

	@Override
	public String toString() {
		return "WriteFaultMessageToKafka [properties=" + properties + ", producer=" + producer + ", classLoader="
				+ classLoader + ", vesEvent=" + vesEvent + ", configuration=" + configuration + "]";
	}

}
