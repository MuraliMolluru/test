
package de.telekom.onap.oran.kafka.application;

import static io.restassured.RestAssured.given;

import de.telekom.onap.oran.kafka.configuration.Configuration;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class RestAssuredClient {

	/**
	 * Method to Call A GET Request using RestAssured.
	 */
	public Response get(String url) {

		Response res = given().relaxedHTTPSValidation().when().header("Content-Type", ContentType.JSON).get(url);

		return res;
	}

	/**
	 * Method to Call A GET Request using RestAssured With Credentials.
	 */
	public Response getWithCredentials(String url) {

		Response res = given().auth()
				.basic(Configuration.getConfiguration().getPolicyUserName(),
						Configuration.getConfiguration().getPolicyPassword())
				.relaxedHTTPSValidation().when().header("Content-Type", ContentType.JSON).get(url);

		return res;
	}

	/**
	 * Method to Call A POST Request using RestAssured.
	 */
	public Response post(String bodyData, String url) {

		Response res = given().relaxedHTTPSValidation().when().header("Content-Type", ContentType.JSON).body(bodyData)
				.post(url);

		return res;
	}

	/**
	 * Method to Call A POST Request using RestAssured.
	 */
	public Response postWithCrendentials(String bodyData, String url) {

		Response res = given().auth()
				.basic(Configuration.getConfiguration().getPolicyUserName(),
						Configuration.getConfiguration().getPolicyPassword())
				.relaxedHTTPSValidation().when().header("Content-Type", ContentType.JSON).body(bodyData).post(url);

		return res;
	}

	/**
	 * Method to Call A PUT Request using RestAssured.
	 */
	public Response put(String bodyData, String url) {

		Response res = given().relaxedHTTPSValidation().when().header("Content-Type", ContentType.JSON).body(bodyData)
				.put(url);
		return res;
	}

	/**
	 * Method to Call A PUT Request using RestAssured.
	 */
	public Response putWithCredentials(String bodyData, String url) {

		Response res = given().auth()
				.basic(Configuration.getConfiguration().getPolicyUserName(),
						Configuration.getConfiguration().getPolicyPassword())
				.relaxedHTTPSValidation().when().header("Content-Type", ContentType.JSON).body(bodyData).put(url);
		return res;
	}

	/**
	 * Method to Call A DELETE Request using RestAssured.
	 */
	public Response delete(String bodyData, String url) {

		Response res = given().relaxedHTTPSValidation().when().header("Content-Type", ContentType.JSON).body(bodyData)
				.delete(url);
		return res;
	}

	/**
	 * Method to Call A DELETE Request using RestAssured.
	 */
	public Response deleteWithCredentails(String url) {

		Response res = given().auth()
				.basic(Configuration.getConfiguration().getPolicyUserName(),
						Configuration.getConfiguration().getPolicyPassword())
				.relaxedHTTPSValidation().when().header("Content-Type", ContentType.JSON).delete(url);
		return res;
	}

}
