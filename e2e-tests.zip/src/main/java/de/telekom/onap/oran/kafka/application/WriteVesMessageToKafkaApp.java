// package de.telekom.onap.oran.kafka.application;
//
// import org.apache.kafka.clients.producer.KafkaProducer;
// import org.slf4j.Logger;
// import org.slf4j.LoggerFactory;
//
// import de.telekom.onap.dcae.vescollector.model.VesEvent;
// import de.telekom.onap.oran.kafka.configuration.Configuration;
// import de.telekom.onap.oran.kafka.producer.WriteFaultMessageToKafka;
// import de.telekom.onap.oran.kafka.producer.WritePMMessageToKafka;
//
// public class WriteVesMessageToKafkaApp {
// private static final Logger log = LoggerFactory.getLogger(WriteVesMessageToKafkaApp.class);
//// private static final org.apache.logging.log4j.Logger LOGGER = LogManager
//// .getLogger(WriteVesMessageToKafkaApp.class.getName());
// ClassLoader classLoader;
// WriteFaultMessageToKafka writeFaultMessageToKafka;
// VesEvent vesEvent = null;
// Configuration configuration;
// WritePMMessageToKafka pmMessageToKafka;
//
// public WriteVesMessageToKafkaApp() {
//
// classLoader = getClass().getClassLoader();
// writeFaultMessageToKafka = new WriteFaultMessageToKafka();
// configuration = Configuration.getConfiguration();
// pmMessageToKafka = new WritePMMessageToKafka();
// }
//
//// public static void main(String[] args) {
//// WriteVesMessageToKafkaApp kafkaApp = new WriteVesMessageToKafkaApp();
//// kafkaApp.startApplication();
//// }
//
// public void startApplication() {
// sendFmDownMessage();
//
// sendFmUpMessage();
//
// // System.out.println("Sending PM messages...");
// log.info("Testing:Sending PM messages...");
// sendGuardPmMessage();
// // sleep for few second and send onset messages - to maintain the order of Guard
// // and Onset messages
// try {
// Thread.sleep(configuration.getSleepTime());
// } catch (InterruptedException e) {
// log.error(e.getMessage(), e);
// }
//
// sendOnsetPmMessage();
//
// try {
// Thread.sleep(configuration.getSleepTime());
// } catch (InterruptedException e) {
// log.error(e.getMessage(), e);
// }
//
// sendAbatedPmMessage();
//
// }
//
// public void sendGuardPmMessage() {
// String fileName = "vesEvents/vesPerf3gppGUARD.json";
// KafkaProducer<String, String> producer = pmMessageToKafka.getProducer();
// System.out.println("onap.kafka.boostrapServers=" + configuration.getBoostrapServers());
// vesEvent = pmMessageToKafka.getVesEvent(classLoader.getResource(fileName).getFile());
// for (int i = 1; i <= configuration.getNumberOfGuardMessages(); i++) {
// // System.out.println("Sending Guard message...");
// log.info("Testing:Sending Guard message...");
// // LOGGER.info("Logger:Sending Guard message...");
// pmMessageToKafka.sendMsg(producer, vesEvent);
// }
//
// }
//
// public void sendOnsetPmMessage() {
// String fileName = "vesEvents/vesPerf3gppONSET.json";
// KafkaProducer<String, String> producer = pmMessageToKafka.getProducer();
// vesEvent = pmMessageToKafka.getVesEvent(classLoader.getResource(fileName).getFile());
// for (int i = 1; i <= configuration.getNumberOfOnsetMessages(); i++) {
// // System.out.println("Sending Onset message...");
// log.info("Sending Onset message...");
// pmMessageToKafka.sendMsg(producer, vesEvent);
// }
// }
//
// public void sendAbatedPmMessage() {
// String fileName = "vesEvents/vesPerf3gppABATED.json";
// KafkaProducer<String, String> producer = pmMessageToKafka.getProducer();
// vesEvent = pmMessageToKafka.getVesEvent(classLoader.getResource(fileName).getFile());
// for (int i = 1; i <= configuration.getNumberOfAbateddMessages(); i++) {
// // System.out.println("Sending Abated message...");
// log.info("Sending Abated message...");
// pmMessageToKafka.sendMsg(producer, vesEvent);
// }
// }
//
// public void sendFmDownMessage() {
// String fileName = "vesEvents/VesFaultDownDU7.json";
// KafkaProducer<String, String> producer = writeFaultMessageToKafka.getProducer();
// String file = classLoader.getResource(fileName).getFile();
// // System.out.println("Sending FM message..." + file);
// log.info("Sending FM message..." + file);
// System.out.println("onap.kafka.boostrapServers=" + configuration.getBoostrapServers());
// vesEvent = writeFaultMessageToKafka.getVesEvent(file);
// writeFaultMessageToKafka.sendMsg(producer, vesEvent);
// }
//
// public void sendFmUpMessage() {
// String fileName = "vesEvents/VesFaultUPDU7.json";
// KafkaProducer<String, String> producer = writeFaultMessageToKafka.getProducer();
// String file = classLoader.getResource(fileName).getFile();
// // System.out.println("Sending FM message..." + file);
// log.info("Sending FM message..." + file);
// vesEvent = writeFaultMessageToKafka.getVesEvent(file);
// writeFaultMessageToKafka.sendMsg(producer, vesEvent);
// }
//
// public VesEvent getVesEvent() {
// return vesEvent;
// }
// }
