# Getting Started

### Reference Documentation
Preconditions:

    - sudo apt install protobuf-compiler 
    - Check-out, install the DCAE_ves_collector, DMaaP_MR from onap-api-gen
    - Forward the service
        kubectl port-forward service/dcae-ves-collector 8080:8080
    - Set "auth.method": "noAuth" on VES-Collector (consul)
    - Insert Domain "perf3gpp" in VES collector configuration (see botton)
    - Set "security.sslDisable": true on HVVES-Collector (consul)
    
    
Starting the simulator:

    - start de.telekom.onap.oran.netsim.net.SimulatorMain
    - feeds heartbeat, fault and 3gpp ves events to the ves, hvves collector
    - simulates a small net with CU, DU (2), RU (8[5,3])
Configuration:

    - found in scr/main/resources
    - normally not to be changed....

VES-adapter configuration:

```
{
  "auth.method": "noAuth",
  "collector.dynamic.config.update.frequency": "5",
  "collector.truststore.passwordfile": "/opt/app/dcae-certificate/trust.pass",
  "collector.inputQueue.maxPending": "8096",
  "collector.externalSchema.mappingFileLocation": "./etc/externalRepo/schema-map.json",
  "event.transform.flag": "0",
  "collector.service.secure.port": "8443",
  "collector.schema.checkflag": "1",
  "collector.dmaap.streamid": "fault=ves-fault|syslog=ves-syslog|heartbeat=ves-heartbeat|measurement=ves-measurement|measurementsForVfScaling=ves-measurement|mobileFlow=ves-mobileflow|other=ves-other|stateChange=ves-statechange|thresholdCrossingAlert=ves-thresholdCrossingAlert|voiceQuality=ves-voicequality|sipSignaling=ves-sipsignaling|notification=ves-notification|pnfRegistration=ves-pnfRegistration|3GPP-FaultSupervision=ves-3gpp-fault-supervision|3GPP-Heartbeat=ves-3gpp-heartbeat|3GPP-Provisioning=ves-3gpp-provisioning|3GPP-PerformanceAssurance=ves-3gpp-performance-assurance|perf3gpp=ves-3gpp-performance",
  "collector.schema.file": "{\"v1\":\"./etc/CommonEventFormat_27.2.json\",\"v2\":\"./etc/CommonEventFormat_27.2.json\",\"v3\":\"./etc/CommonEventFormat_27.2.json\",\"v4\":\"./etc/CommonEventFormat_27.2.json\",\"v5\":\"./etc/CommonEventFormat_28.4.1.json\",\"v7\":\"./etc/CommonEventFormat_30.2_ONAP.json\"}",
  "collector.externalSchema.schemasLocation": "./etc/externalRepo/",
  "collector.keystore.passwordfile": "/opt/app/dcae-certificate/jks.pass",
  "event.externalSchema.schemaRefPath": "$.event.stndDefinedFields.schemaReference",
  "event.externalSchema.stndDefinedDataPath": "$.event.stndDefinedFields.data",
  "streams_publishes": {
    "ves-3gpp-provisioning": {
      "type": "message_router",
      "dmaap_info": {
        "topic_url": "http://message-router:3904/events/unauthenticated.SEC_3GPP_PROVISIONING_OUTPUT/"
      }
    },
    "ves-measurement": {
      "type": "message_router",
      "dmaap_info": {
        "topic_url": "http://message-router:3904/events/unauthenticated.VES_MEASUREMENT_OUTPUT/"
      }
    },
    "ves-3gpp-fault-supervision": {
      "type": "message_router",
      "dmaap_info": {
        "topic_url": "http://message-router:3904/events/unauthenticated.SEC_3GPP_FAULTSUPERVISION_OUTPUT/"
      }
    },
    "ves-3gpp-performance-assurance": {
      "type": "message_router",
      "dmaap_info": {
        "topic_url": "http://message-router:3904/events/unauthenticated.SEC_3GPP_PERFORMANCEASSURANCE_OUTPUT/"
      }
    },
    "ves-fault": {
      "type": "message_router",
      "dmaap_info": {
        "topic_url": "http://message-router:3904/events/unauthenticated.SEC_FAULT_OUTPUT/"
      }
    },
    "ves-pnfRegistration": {
      "type": "message_router",
      "dmaap_info": {
        "topic_url": "http://message-router:3904/events/unauthenticated.VES_PNFREG_OUTPUT/"
      }
    },
    "ves-other": {
      "type": "message_router",
      "dmaap_info": {
        "topic_url": "http://message-router:3904/events/unauthenticated.SEC_OTHER_OUTPUT/"
      }
    },
    "ves-heartbeat": {
      "type": "message_router",
      "dmaap_info": {
        "topic_url": "http://message-router:3904/events/unauthenticated.SEC_HEARTBEAT_OUTPUT/"
      }
    },
    "ves-notification": {
      "type": "message_router",
      "dmaap_info": {
        "topic_url": "http://message-router:3904/events/unauthenticated.VES_NOTIFICATION_OUTPUT/"
      }
    },
    "ves-3gpp-heartbeat": {
      "type": "message_router",
      "dmaap_info": {
        "topic_url": "http://message-router:3904/events/unauthenticated.SEC_3GPP_HEARTBEAT_OUTPUT/"
      }
    },
    "ves-3gpp-performance": {
      "type": "message_router",
      "dmaap_info": {
        "topic_url": "http://message-router:3904/events/unauthenticated.VES_PERF3GPP_OUTPUT/"
      }
    }
  },
  "collector.service.port": "8080",
  "collector.keystore.file.location": "/opt/app/dcae-certificate/cert.jks",
  "collector.externalSchema.checkflag": 1,
  "services_calls": [],
  "collector.truststore.file.location": "/opt/app/dcae-certificate/trust.jks",
  "header.authlist": "sample1,$2a$10$0buh.2WeYwN868YMwnNNEuNEAMNYVU9.FSMJGyIKV3dGET/7oGOi6|demouser,$2a$10$1cc.COcqV/d3iT2N7BjPG.S6ZKv2jpb9a5MV.o7lMih/GpjJRX.Ce"
}
``` 